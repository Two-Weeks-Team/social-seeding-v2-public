"""Placeholder ADK agent for terraform-compute module.

This file is replaced by the real agent bundle at deploy time. Its sole purpose
is to satisfy the `google_vertex_ai_reasoning_engine.spec.source_code_spec`
required field on `terraform apply`. The real agent code is published from
packages/agents/ (D38 build pipeline).

Cites: D17 (Agent Runtime), D38 (PreviewForge build agents).
"""


def root_agent(*_args, **_kwargs):
    return {"status": "placeholder", "d_id": "D17"}
